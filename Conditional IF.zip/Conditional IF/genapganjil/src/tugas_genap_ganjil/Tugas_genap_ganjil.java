/*
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas_genap_ganjil;

import java.util.Scanner;

/**
 *
 * @author Nuri Astutik
 */
public class Tugas_genap_ganjil {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner inputan = new Scanner(System.in);
        System.out.print("Input Bilangan Bulat : ");
        int angka = inputan.nextInt();
        if(angka % 2 == 0) //Jika angka dibagi 2 sisa 0
            System.out.print(angka+" adalah bilangan genap");
        else
            System.out.print(angka+" adalah bilangan ganjil");
    }
    
}
